package com.mitanshu.locker

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.service.quicksettings.TileService
import android.widget.Toast

object Util {
    fun accessibilityIntent() =
        Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun needService(c: Context) {
        Toast.makeText(c, "Pehle Accessibility me 'Screen Lock' ON karo", Toast.LENGTH_LONG).show()
    }

    @Suppress("DEPRECATION")
    fun openSettingsFromTile(t: TileService) {
        val i = accessibilityIntent()
        if (Build.VERSION.SDK_INT >= 34) {
            t.startActivityAndCollapse(
                PendingIntent.getActivity(t, 0, i, PendingIntent.FLAG_IMMUTABLE)
            )
        } else {
            t.startActivityAndCollapse(i)
        }
    }
}
