# Screen Lock (Android)

Features
- Home screen par "Lock" icon / 1x1 widget -> ek tap me screen lock
- Quick Settings tiles: "Lock Screen" aur "Floating Lock"
- Floating lock button: kahin bhi drag karo, tap = lock

## APK banana (GitHub Actions, free)
1. github.com par naya repo banao aur is folder ki saari files upload/push karo.
2. Repo > Actions > "Build APK" run hone do (ya "Run workflow").
3. Run khatam hone par neeche "Artifacts" se ScreenLock-APK download karo, zip khol ke app-debug.apk install karo.

Android Studio se: folder open karo > Build > Build APK(s).

Requirement: Android 9 (API 28) ya upar.
