package com.mitanshu.locker

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class LockTileService : TileService() {
    override fun onStartListening() {
        qsTile?.apply {
            state = Tile.STATE_INACTIVE
            updateTile()
        }
    }

    override fun onClick() {
        if (!LockAccessibilityService.lock()) {
            Util.needService(this)
            Util.openSettingsFromTile(this)
        }
    }
}
