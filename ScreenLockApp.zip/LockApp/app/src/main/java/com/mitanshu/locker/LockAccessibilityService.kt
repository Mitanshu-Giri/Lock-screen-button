package com.mitanshu.locker

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.ImageView
import kotlin.math.hypot

class LockAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: LockAccessibilityService? = null

        fun isRunning() = instance != null

        /** Screen lock karta hai. true = command bhej di gayi. */
        fun lock(): Boolean =
            instance?.performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN) ?: false

        fun setFloating(ctx: Context, on: Boolean) {
            Prefs.setFloatingOn(ctx, on)
            instance?.refreshFloating()
        }
    }

    private var button: View? = null
    private var params: WindowManager.LayoutParams? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        refreshFloating()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        hideButton()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        hideButton()
        instance = null
        super.onDestroy()
    }

    fun refreshFloating() {
        if (Prefs.floatingOn(this)) showButton() else hideButton()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showButton() {
        if (button != null) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val size = dp(56)

        val bg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#E61E88E5"))
        }
        val view = ImageView(this).apply {
            setImageResource(R.drawable.ic_lock)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = bg
            elevation = dp(6).toFloat()
        }

        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = Prefs.posX(this@LockAccessibilityService)
            y = Prefs.posY(this@LockAccessibilityService)
        }

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var startX = 0
        var startY = 0
        var downX = 0f
        var downY = 0f
        var moved = false

        view.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    downX = e.rawX; downY = e.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!moved && hypot(dx, dy) > slop) moved = true
                    if (moved) {
                        val dm = resources.displayMetrics
                        lp.x = (startX + dx).toInt().coerceIn(0, dm.widthPixels - size)
                        lp.y = (startY + dy).toInt().coerceIn(0, dm.heightPixels - size)
                        wm.updateViewLayout(v, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) Prefs.setPos(this, lp.x, lp.y) else lock()
                    true
                }
                else -> false
            }
        }

        try {
            wm.addView(view, lp)
            button = view
            params = lp
        } catch (_: Exception) {
        }
    }

    private fun hideButton() {
        val v = button ?: return
        try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(v)
        } catch (_: Exception) {
        }
        button = null
        params = null
    }
}
