package com.mitanshu.locker

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class FloatTileService : TileService() {
    override fun onStartListening() = refresh()

    override fun onClick() {
        if (!LockAccessibilityService.isRunning()) {
            Util.needService(this)
            Util.openSettingsFromTile(this)
            return
        }
        LockAccessibilityService.setFloating(this, !Prefs.floatingOn(this))
        refresh()
    }

    private fun refresh() {
        qsTile?.apply {
            state = if (Prefs.floatingOn(this@FloatTileService) && LockAccessibilityService.isRunning())
                Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            updateTile()
        }
    }
}
