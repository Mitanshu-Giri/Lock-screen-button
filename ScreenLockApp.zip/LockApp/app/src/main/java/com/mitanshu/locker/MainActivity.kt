package com.mitanshu.locker

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var floatSwitch: Switch
    private var updating = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = getString(R.string.settings_label)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }

        status = TextView(this).apply { textSize = 18f }
        root.addView(status)

        root.addView(Button(this).apply {
            text = "Accessibility settings kholo"
            setOnClickListener { startActivity(Util.accessibilityIntent()) }
        })

        floatSwitch = Switch(this).apply {
            text = "Floating lock button  "
            textSize = 17f
            setPadding(0, dp(16), 0, dp(16))
            setOnCheckedChangeListener { _, checked ->
                if (updating) return@setOnCheckedChangeListener
                if (!LockAccessibilityService.isRunning()) {
                    Util.needService(this@MainActivity)
                    updating = true; isChecked = false; updating = false
                } else {
                    LockAccessibilityService.setFloating(this@MainActivity, checked)
                }
            }
        }
        root.addView(floatSwitch)

        // --- Size slider (24..72 dp) ---
        val sizeLabel = TextView(this).apply { textSize = 15f }
        val sizeBar = SeekBar(this).apply { max = 48; progress = Prefs.sizeDp(this@MainActivity) - 24 }
        sizeLabel.text = "Button size: ${Prefs.sizeDp(this)}"
        // --- Transparency slider (visibility 20..100 %) ---
        val alphaLabel = TextView(this).apply { textSize = 15f; setPadding(0, dp(12), 0, 0) }
        val alphaBar = SeekBar(this).apply { max = 80; progress = Prefs.alphaPct(this@MainActivity) - 20 }
        alphaLabel.text = "Visibility: ${Prefs.alphaPct(this)}%  (kam = zyada transparent)"

        val listener = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                val size = sizeBar.progress + 24
                val alpha = alphaBar.progress + 20
                sizeLabel.text = "Button size: $size"
                alphaLabel.text = "Visibility: $alpha%  (kam = zyada transparent)"
                if (fromUser) Prefs.setStyle(this@MainActivity, size, alpha)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {
                LockAccessibilityService.instance?.restyle()
            }
        }
        sizeBar.setOnSeekBarChangeListener(listener)
        alphaBar.setOnSeekBarChangeListener(listener)
        root.addView(sizeLabel)
        root.addView(sizeBar)
        root.addView(alphaLabel)
        root.addView(alphaBar)

        root.addView(Button(this).apply {
            text = "Test: abhi screen lock karo"
            setOnClickListener {
                if (!LockAccessibilityService.lock()) Util.needService(this@MainActivity)
            }
        })

        root.addView(TextView(this).apply {
            textSize = 15f
            setPadding(0, dp(24), 0, 0)
            gravity = Gravity.START
            text = """
                Kaise use karein:

                1) Upar ka button dabao -> Installed apps / Downloaded apps -> "Screen Lock" -> ON.
                   (Agar ON na ho: Phone Settings > Apps > Screen Lock > 3 dots > "Allow restricted settings", phir dobara try karo.)

                2) Home screen par: "Lock" naam ka icon (ya widget) lagao. Dabate hi screen lock.
                   Widget ke liye home screen par long-press > Widgets > Screen Lock.

                3) Quick panel: panel kholo > pencil/edit icon > "Lock Screen" aur "Floating Lock" tiles ko upar kheencho.

                4) Floating button: switch ON karo ya tile use karo. Button ko ungli se kahin bhi khiskao. Tap karne par screen lock.
                   Size aur transparency upar ke sliders se badlo.
            """.trimIndent()
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        val on = LockAccessibilityService.isRunning()
        status.text = if (on) "Service: ON ✅" else "Service: OFF ❌ (pehle ON karo)"
        updating = true
        floatSwitch.isChecked = on && Prefs.floatingOn(this)
        updating = false
    }
}
