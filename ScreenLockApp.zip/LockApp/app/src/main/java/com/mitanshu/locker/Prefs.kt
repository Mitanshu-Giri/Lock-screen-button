package com.mitanshu.locker

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("lock_prefs", Context.MODE_PRIVATE)

    fun floatingOn(c: Context) = sp(c).getBoolean("floating", false)
    fun setFloatingOn(c: Context, v: Boolean) = sp(c).edit().putBoolean("floating", v).apply()

    fun posX(c: Context) = sp(c).getInt("x", 40)
    fun posY(c: Context) = sp(c).getInt("y", 400)
    fun setPos(c: Context, x: Int, y: Int) = sp(c).edit().putInt("x", x).putInt("y", y).apply()

    fun sizeDp(c: Context) = sp(c).getInt("size_dp", 44)
    fun alphaPct(c: Context) = sp(c).getInt("alpha_pct", 60)
    fun setStyle(c: Context, sizeDp: Int, alphaPct: Int) =
        sp(c).edit().putInt("size_dp", sizeDp).putInt("alpha_pct", alphaPct).apply()
}
