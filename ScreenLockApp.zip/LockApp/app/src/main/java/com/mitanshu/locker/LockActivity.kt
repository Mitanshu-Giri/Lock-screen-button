package com.mitanshu.locker

import android.app.Activity
import android.os.Bundle

/** Transparent activity: icon dabao -> screen lock -> band. */
class LockActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!LockAccessibilityService.lock()) {
            Util.needService(this)
            startActivity(Util.accessibilityIntent())
        }
        finish()
    }
}
